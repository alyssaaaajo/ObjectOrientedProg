/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.mainmytime;

/**
 *
 * @author USER
 */

public class MainMyTime{

    public static void main(String[] args) {
        MyTime clock = new MyTime(23, 59, 56);
        
//        System.out.println(clock);
//        clock.tickBySecond();
//        System.out.println(clock);
//        clock.tickBySecond();
//        System.out.println(clock);
//        
        clock.advanceTime(43200);
        System.out.println(clock);
    }
}